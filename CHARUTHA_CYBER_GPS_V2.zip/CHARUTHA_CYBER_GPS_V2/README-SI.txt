CHARUTHA CYBER GPS V2.0 — SETUP

මෙය consent-based GPS sharing starter project එකකි.
Cross-device live sharing සඳහා Firebase Realtime Database setup අවශ්‍යයි.

1. Firebase Console: https://console.firebase.google.com/
2. Create project එකක් හදන්න.
3. Authentication > Sign-in method > Anonymous enable කරන්න.
4. Realtime Database එකක් create කරන්න.
5. Project settings > Your apps > Web app එකක් add කර Firebase config values
   firebase-config.js තුළ දාන්න.
6. Realtime Database Rules වෙත database.rules.json හි rules දාන්න.
7. සියලුම files GitHub repository එකට upload කර Vercel deploy කරන්න.
8. HTTPS website එක විවෘත කර location permission allow කරන්න.

වැදගත් ආරක්ෂක සටහන:
- Share link එක bearer invitation එකක්. එය දන්නා අයට session එකට ප්‍රවේශ විය හැකි නිසා
  විශ්වාස කරන පුද්ගලයාට පමණක් යවන්න.
- මෙම starter rules demo සඳහා සරලයි; production භාවිතයට පෙර per-session owner/member
  authorization, expiry, rate limits සහ server-side validation එකතු කරන්න.
- Location share කරන පුද්ගලයාට පැහැදිලිව දැනුම් දී ඔහුගේ/ඇයගේ අවසරය ලබාගන්න.
- Phone number එකකින් පමණක් location සොයාගැනීම මෙහි සිදු නොවේ.
- Firebase config placeholder values පුරවන තුරු multi-device sharing ක්‍රියා නොකරයි.
- GPS සඳහා HTTPS සහ browser permission අවශ්‍යයි.
