const $ = id => document.getElementById(id);
const map = L.map('map').setView([7.8731,80.7718],7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(map);
let marker=null, accuracyCircle=null, watchId=null, db=null, sessionId=null, sessionRef=null;
const params=new URLSearchParams(location.search);
const joinId=params.get('join');
function setStatus(s){$('connection').textContent=s;$('mapState').textContent=s;}
function showLocation(data){
 if(!data || typeof data.lat!=='number' || typeof data.lng!=='number') return;
 $('lat').textContent=data.lat.toFixed(6);$('lng').textContent=data.lng.toFixed(6);$('accuracy').textContent=Math.round(data.accuracy||0)+' m';
 const point=[data.lat,data.lng];
 if(!marker) marker=L.marker(point).addTo(map).bindPopup('Consenting device');
 else marker.setLatLng(point);
 if(accuracyCircle) accuracyCircle.setLatLng(point).setRadius(data.accuracy||20);
 else accuracyCircle=L.circle(point,{radius:data.accuracy||20,color:'#00aa66'}).addTo(map);
 map.setView(point,16);
}
function initFirebase(){
 const c=window.FIREBASE_CONFIG||{};
 if(!c.apiKey||c.apiKey.startsWith('PASTE_')||!c.databaseURL||c.projectId.startsWith('YOUR_')) throw Error('Firebase setup required');
 if(!firebase.apps.length) firebase.initializeApp(c);
 return firebase.auth().signInAnonymously().then(()=>firebase.database());
}
if(joinId){
 $('ownerPanel').classList.add('hidden');$('joinPanel').classList.remove('hidden');
 $('consentBtn').onclick=async()=>{
  try{
   db=await initFirebase();sessionRef=db.ref('sessions/'+joinId);
   $('consentBtn').disabled=true;$('consentBtn').textContent='REQUESTING LOCATION PERMISSION…';
   if(!navigator.geolocation) throw Error('Geolocation unavailable');
   watchId=navigator.geolocation.watchPosition(async pos=>{
    const d={lat:pos.coords.latitude,lng:pos.coords.longitude,accuracy:pos.coords.accuracy,updatedAt:Date.now(),sharing:true};
    await sessionRef.child('location').set(d);setStatus('SHARING WITH SESSION OWNER');
   },err=>{alert('Location permission/error: '+err.message);$('consentBtn').disabled=false;},{enableHighAccuracy:true,maximumAge:0,timeout:20000});
  }catch(e){alert(e.message);$('consentBtn').disabled=false;}
 };
}
$('createBtn').onclick=async()=>{
 try{
  db=await initFirebase();sessionId=Array.from(crypto.getRandomValues(new Uint8Array(18))).map(x=>x.toString(16).padStart(2,'0')).join('');
  sessionRef=db.ref('sessions/'+sessionId);
  await sessionRef.child('label').set(($('deviceLabel').value||'Shared device').slice(0,32));
  const url=new URL(location.href);url.search='?join='+sessionId;
  $('shareLink').value=url.href;$('shareArea').classList.remove('hidden');
  setStatus('SESSION CREATED — WAITING FOR CONSENT');
  sessionRef.child('location').on('value',snap=>{const d=snap.val();if(d&&d.sharing){showLocation(d);setStatus('DEVICE SHARING LOCATION');}});
 }catch(e){alert('Firebase setup is not complete: '+e.message);}
};
$('copyBtn').onclick=async()=>{try{await navigator.clipboard.writeText($('shareLink').value);alert('Invitation link copied');}catch(e){$('shareLink').select();alert('Copy the selected link');}};
$('stopBtn').onclick=async()=>{
 if(watchId!==null){navigator.geolocation.clearWatch(watchId);watchId=null;}
 if(sessionRef){try{await sessionRef.child('location/sharing').set(false);}catch(e){}}
 setStatus('SHARING STOPPED');
};
window.addEventListener('beforeunload',()=>{if(watchId!==null)navigator.geolocation.clearWatch(watchId);});